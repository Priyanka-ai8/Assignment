# Movie_Recommendation_System
A content based movie recommender system using cosine similarity
